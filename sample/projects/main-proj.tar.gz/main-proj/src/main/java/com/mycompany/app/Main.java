package com.mycompany.app;

import uk.co.optimisticpanda.versionfind.Versions;

public class Main {

	public static void main(String[] args) {
		new Versions().getVersions().forEach(
				(k, v) -> System.out.println(k + " -> " + v));
	} 
}
